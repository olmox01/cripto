import os
import platform
import socket

def clear_screen():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

def get_ip_address():
    return socket.gethostbyname(socket.gethostname())

def run_command(command):
    if platform.system() == "Windows":
        os.system(command)
    else:
        os.system(f"bash -c '{command}'")
