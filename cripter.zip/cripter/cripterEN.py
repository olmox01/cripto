#!/usr/bin/env python3

import platform
import socket
import colorama
from colorama import init
from cryptography.exceptions import InvalidTag
from bootloader import bootloader
from login import select_language, load_translations, get_password_with_stars, generate_system_key
from file_manager import clear_screen
from encryption import encrypt_process, decrypt_content_process, read_section_process
from platform_utils import get_ip_address

# Initialize colorama
init()

def main():
    language = select_language()
    translations = load_translations(language)
    
    clear_screen()
    print(translations.WELCOME)
    username_or_key = input(translations.ENTER_USERNAME_OR_KEY).strip()
    
    if len(username_or_key) == 64:
        # Assume it's a system key
        system_key = username_or_key
        username = "dumpy"  # Create a temporary account "dumpy"
    else:
        username = username_or_key
        if len(username) > 10:
            print(translations.USERNAME_TOO_LONG)
            username = input(translations.ENTER_USERNAME).strip()
        
        password_system = get_password_with_stars(translations.ENTER_SYSTEM_PASSWORD)
        system_key = generate_system_key(username, password_system)
    
    ip = get_ip_address()
    print(translations.DETECTED_IP.format(ip))
    
    # Run the bootloader
    bootloader(translations)
    print(translations.BOOTLOADER_COMPLETE)  # Ensure bootloader completion message is shown
   
    while True:
        try:
            clear_screen()
            print(f"{translations.USERNAME}: {username}")
            print(f"{translations.IP}: {ip}")
            print(f"{translations.SYSTEM_KEY}: {system_key}")
            print(f"Operating System: {platform.system()}")
            print(translations.MAIN_MENU)
            print("1. " + translations.ENCRYPT)
            print("2. " + translations.DECRYPT_CONTENT)
            print("3. " + translations.READ_SECTION)
            print("4. " + translations.EXIT)
            choice = input(translations.CHOOSE_OPTION).strip()
           
            if choice == '1':
                encrypt_process(system_key, username, ip, translations)
            elif choice == '2':
                decrypt_content_process(translations)
            elif choice == '3':
                read_section_process(system_key, translations)
            elif choice == '4':
                print(translations.EXITING)
                break
            else:
                print(translations.INVALID_OPTION)
        except Exception as e:
            print(f"Unexpected error: {e}")
            break
   
    print(colorama.Style.RESET_ALL)

if __name__ == "__main__":
    main()