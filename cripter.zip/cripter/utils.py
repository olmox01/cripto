import os
import platform
import subprocess
import sys
import time
import getpass
import json
import hashlib
import importlib
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidTag

FIXED_KEY = b'This_is_a_fixed_key_256_bit_for_username_recovery!'

def load_translations(language):
    try:
        translations = importlib.import_module(f"translations_{language}")
        return translations
    except ImportError:
        print(f"Error: Translation file for '{language}' not found.")
        sys.exit(1)

def select_language():
    print("Select language / Seleziona la lingua:")
    print("1. English")
    print("2. Italiano")
    choice = input("Choose an option (1-2): ").strip()
    if choice == '1':
        return "en"
    elif choice == '2':
        return "it"
    else:
        print("Error: Invalid option.")
        sys.exit(1)

def bootloader(translations):
    print(translations.STARTING_BOOTLOADER)
    system = platform.system()
    print(translations.DETECTED_OS.format(system))

    if sys.version_info < (3, 6):
        print(translations.PYTHON_VERSION_ERROR)
        sys.exit(1)

    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"])
    except subprocess.CalledProcessError:
        print(translations.PIP_ERROR)
        sys.exit(1)

    libraries = ['cryptography', 'colorama']
    for lib in libraries:
        try:
            __import__(lib)
            print(translations.LIBRARY_INSTALLED.format(lib))
        except ImportError:
            print(translations.LIBRARY_NOT_INSTALLED.format(lib))
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", lib])
                print(translations.LIBRARY_INSTALLATION_COMPLETE.format(lib))
            except subprocess.CalledProcessError:
                print(translations.LIBRARY_INSTALLATION_ERROR.format(lib))
                sys.exit(1)

    print(translations.CHECKING, end='', flush=True)
    for _ in range(10):
        print(".", end='', flush=True)
        time.sleep(0.1)
    print(translations.BOOTLOADER_COMPLETE)

def get_password_with_stars(prompt):
    return getpass.getpass(prompt)

def generate_system_key(username, password):
    combined = (username + password).encode('utf-8')
    return hashlib.sha256(combined).hexdigest()

def recover_username(system_key, password):
    try:
        combined = (FIXED_KEY + system_key.encode('utf-8') + password.encode('utf-8'))
        username = hashlib.sha256(combined).hexdigest()
        return username
    except Exception as e:
        print(f"Error in recover_username: {e}")
        return None

def encrypt_file(plaintext, password_file, password_system, username, ip, original_extension):
    salt_file = os.urandom(16)
    kdf_file = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt_file,
        iterations=600000,
        backend=default_backend()
    )
    K_file = kdf_file.derive(password_file.encode())
    iv_content = os.urandom(12)
    cipher_content = Cipher(algorithms.AES(K_file), modes.GCM(iv_content), backend=default_backend())
    encryptor_content = cipher_content.encryptor()
    content_with_extension = json.dumps({"extension": original_extension}).encode('utf-8') + plaintext
    ciphertext_content = encryptor_content.update(content_with_extension) + encryptor_content.finalize()
    tag_content = encryptor_content.tag

    section_plain = json.dumps({"ip": ip, "username": username}).encode('utf-8')
    salt_section = os.urandom(16)
    combined_password = password_file + ":" + password_system
    kdf_section = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt_section,
        iterations=600000,
        backend=default_backend()
    )
    K_section = kdf_section.derive(combined_password.encode())
    iv_section = os.urandom(12)
    cipher_section = Cipher(algorithms.AES(K_section), modes.GCM(iv_section), backend=default_backend())
    encryptor_section = cipher_section.encryptor()
    ciphertext_section = encryptor_section.update(section_plain) + encryptor_section.finalize()
    tag_section = encryptor_section.tag

    len_content = len(ciphertext_content).to_bytes(4, 'big')
    data = (len_content + salt_file + iv_content + tag_content + ciphertext_content +
            salt_section + iv_section + tag_section + ciphertext_section)
    return data

def decrypt_content(encrypted_data, password_file):
    len_content = int.from_bytes(encrypted_data[:4], 'big')
    salt_file = encrypted_data[4:20]
    iv_content = encrypted_data[20:32]
    tag_content = encrypted_data[32:48]
    ciphertext_content = encrypted_data[48:48 + len_content]
    kdf_file = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt_file,
        iterations=600000,
        backend=default_backend()
    )
    K_file = kdf_file.derive(password_file.encode())
    cipher_content = Cipher(algorithms.AES(K_file), modes.GCM(iv_content, tag_content), backend=default_backend())
    decryptor_content = cipher_content.decryptor()
    plaintext = decryptor_content.update(ciphertext_content) + decryptor_content.finalize()
    return plaintext

def decrypt_section(encrypted_data, password_file, password_system):
    len_content = int.from_bytes(encrypted_data[:4], 'big')
    offset = 4 + 16 + 12 + 16 + len_content
    salt_section = encrypted_data[offset:offset + 16]
    iv_section = encrypted_data[offset + 16:offset + 28]
    tag_section = encrypted_data[offset + 28:offset + 44]
    ciphertext_section = encrypted_data[offset + 44:]
    combined_password = password_file + ":" + password_system
    kdf_section = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt_section,
        iterations=600000,
        backend=default_backend()
    )
    K_section = kdf_section.derive(combined_password.encode())
    cipher_section = Cipher(algorithms.AES(K_section), modes.GCM(iv_section, tag_section), backend=default_backend())
    decryptor_section = cipher_section.decryptor()
    section_plain = decryptor_section.update(ciphertext_section) + decryptor_section.finalize()
    return section_plain

def clear_screen():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

def file_explorer(start_dir, select_file=False):
    current_dir = start_dir
    while True:
        clear_screen()
        print(f"Current directory: {current_dir}")
        items = os.listdir(current_dir)
        dirs = [item for item in items if os.path.isdir(os.path.join(current_dir, item))]
        files = [item for item in items if os.path.isfile(os.path.join(current_dir, item))]
        
        if dirs:
            print("Available folders:")
            for i, d in enumerate(dirs, 1):
                print(f"{i}. {d}")
        else:
            print("No folders available.")
        
        if select_file and files:
            print("Available files:")
            for i, f in enumerate(files, 1):
                print(f"{i}. {f}")
        elif select_file:
            print("No files available.")
        
        command = input("Enter 'cd <number>' to change folder, 'select' to select the current directory, 'select <number>' to select a file, 'back' to go back, 'exit' to exit: ").strip().lower()
        
        if command == "back":
            current_dir = os.path.dirname(current_dir)
        elif command.startswith("cd "):
            try:
                num = int(command[3:].strip())
                if 1 <= num <= len(dirs):
                    current_dir = os.path.join(current_dir, dirs[num-1])
                else:
                    print("Invalid folder number.")
            except ValueError:
                print("Invalid command. Use 'cd <number>'.")
        elif command == "select":
            return current_dir
        elif select_file and command.startswith("select "):
            try:
                num = int(command[7:].strip())
                if 1 <= num <= len(files):
                    return os.path.join(current_dir, files[num-1])
                else:
                    print("Invalid file number.")
            except ValueError:
                print("Invalid command. Use 'select <number>'.")
        elif command == "exit":
            return None
        else:
            print("Invalid command.")

def encrypt_process(system_key, username, ip, translations):
    while True:
        try:
            clear_screen()
            print(translations.ENCRYPTION_OPTIONS)
            print("a. " + translations.CREATE_NEW_ENCRYPTED_FILE)
            print("b. " + translations.ENCRYPT_EXISTING_FILE)
            sub_choice = input(translations.CHOOSE_OPTION).strip().lower()
            while sub_choice not in ['a', 'b']:
                print(translations.INVALID_OPTION)
                sub_choice = input(translations.CHOOSE_OPTION).strip().lower()
            
            if sub_choice == 'a':
                plaintext = input(translations.ENTER_TEXT_TO_ENCRYPT).encode('utf-8')
                original_extension = ".txt"
            else:
                print(translations.SELECT_FILE_TO_ENCRYPT)
                input_path = file_explorer(os.getcwd(), select_file=True)
                if not input_path:
                    return
                print(translations.SELECTED_FILE.format(input_path))
                with open(input_path, 'rb') as f:
                    plaintext = f.read()
                original_extension = os.path.splitext(input_path)[1]
            
            print(translations.SELECT_DESTINATION_FOLDER)
            output_dir = file_explorer(os.getcwd(), select_file=False)
            if not output_dir:
                return
            print(translations.DESTINATION_FOLDER.format(output_dir))
            output_name = input(translations.ENTER_ENCRYPTED_FILE_NAME).strip()
            while not output_name:
                print(translations.NAME_CANNOT_BE_EMPTY)
                output_name = input(translations.ENTER_ENCRYPTED_FILE_NAME).strip()
            output_path = os.path.join(output_dir, output_name + '.crypto')
            print(translations.ENCRYPTED_FILE_PATH.format(output_path))
            
            password_file = get_password_with_stars(translations.ENTER_FILE_PASSWORD)
            while len(password_file) < 8:
                print(translations.PASSWORD_TOO_SHORT)
                password_file = get_password_with_stars(translations.ENTER_FILE_PASSWORD)
            
            encrypted_data = encrypt_file(plaintext, password_file, system_key, username, ip, original_extension)
            with open(output_path, 'wb') as f:
                f.write(encrypted_data)
            print(translations.ENCRYPTED_FILE_SAVED.format(output_path))
            break
        except Exception as e:
            print(translations.ENCRYPTION_ERROR.format(e))
            retry = input(translations.RETRY).strip().lower()
            if retry != 'y':
                break

def decrypt_content_process(translations):
    while True:
        try:
            clear_screen()
            print(translations.SELECT_ENCRYPTED_FILE)
            input_path = file_explorer(os.getcwd(), select_file=True)
            if not input_path or not input_path.endswith('.crypto'):
                print(translations.INVALID_FILE_EXTENSION)
                return
            print(translations.SELECT_DESTINATION_FOLDER)
            output_dir = file_explorer(os.getcwd(), select_file=False)
            if not output_dir:
                return
            output_name = input(translations.ENTER_DECRYPTED_FILE_NAME).strip()
            while not output_name:
                print(translations.NAME_CANNOT_BE_EMPTY)
                output_name = input(translations.ENTER_DECRYPTED_FILE_NAME).strip()
            
            with open(input_path, 'rb') as f:
                encrypted_data = f.read()
            
            password_file = get_password_with_stars(translations.ENTER_FILE_PASSWORD)
            plaintext_with_extension = decrypt_content(encrypted_data, password_file)
            extension_data, plaintext = plaintext_with_extension.split(b'}', 1)
            extension = json.loads(extension_data.decode('utf-8') + '}')["extension"]
            output_path = os.path.join(output_dir, output_name + extension)
            
            with open(output_path, 'wb') as f:
                f.write(plaintext)
            print(translations.DECRYPTED_FILE_SAVED.format(output_path))
            break
        except InvalidTag:
            print(translations.INVALID_PASSWORD_OR_CORRUPTED_DATA)
        except json.JSONDecodeError:
            print(translations.CORRUPTED_SECTION_DATA)
        except Exception as e:
            print(translations.DECRYPTION_ERROR.format(e))
            retry = input(translations.RETRY).strip().lower()
            if retry != 'y':
                break

def read_section_process(system_key, translations):
    while True:
        try:
            clear_screen()
            print(translations.SELECT_ENCRYPTED_FILE)
            input_path = file_explorer(os.getcwd(), select_file=True)
            if not input_path or not input_path.endswith('.crypto'):
                print(translations.INVALID_FILE_EXTENSION)
                return
            with open(input_path, 'rb') as f:
                encrypted_data = f.read()
            
            password_file = get_password_with_stars(translations.ENTER_FILE_PASSWORD)
            section_plain = decrypt_section(encrypted_data, password_file, system_key)
            section = json.loads(section_plain.decode('utf-8'))
            print(translations.DECRYPTED_SECTION.format(section['ip'], section['username']))
            input(translations.RETURN_TO_MENU)
            break
        except InvalidTag:
            print(translations.INVALID_PASSWORD_OR_CORRUPTED_DATA)
        except json.JSONDecodeError:
            print(translations.CORRUPTED_SECTION_DATA)
        except Exception as e:
            print(translations.SECTION_READING_ERROR.format(e))
            retry = input(translations.RETRY).strip().lower()
            if retry != 'y':
                break
