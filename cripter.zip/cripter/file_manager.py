import os
from platform_utils import clear_screen

def file_explorer(start_dir, select_file=False):
    current_dir = start_dir
    while True:
        clear_screen()
        print(f"Current directory: {current_dir}")
        items = os.listdir(current_dir)
        dirs = [item for item in items if os.path.isdir(os.path.join(current_dir, item))]
        files = [item for item in items if os.path.isfile(os.path.join(current_dir, item))]
        
        if dirs:
            print("Available folders:")
            for i, d in enumerate(dirs, 1):
                print(f"{i}. {d}")
        else:
            print("No folders available.")
        
        if select_file and files:
            print("Available files:")
            for i, f in enumerate(files, 1):
                print(f"{i}. {f}")
        elif select_file:
            print("No files available.")
        
        command = input("Enter 'cd <number>' to change folder, 'select' to select the current directory, 'select <number>' to select a file, 'back' to go back, 'exit' to exit: ").strip().lower()
        
        if command == "back":
            current_dir = os.path.dirname(current_dir)
        elif command.startswith("cd "):
            try:
                num = int(command[3:].trip())
                if 1 <= num <= len(dirs):
                    current_dir = os.path.join(current_dir, dirs[num-1])
                else:
                    print("Invalid folder number.")
            except ValueError:
                print("Invalid command. Use 'cd <number>'.")
        elif command == "select":
            return current_dir
        elif select_file and command.startswith("select "):
            try:
                num = int(command[7:].strip())
                if 1 <= num <= len(files):
                    return os.path.join(current_dir, files[num-1])
                else:
                    print("Invalid file number.")
            except ValueError:
                print("Invalid command. Use 'select <number>'.")
        elif command == "exit":
            return None
        else:
            print("Invalid command.")
