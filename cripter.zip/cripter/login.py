import sys
import getpass
import hashlib
import importlib

FIXED_KEY = b'This_is_a_fixed_key_256_bit_for_username_recovery!'

def load_translations(language):
    try:
        translations = importlib.import_module(f"translations_{language}")
        return translations
    except ImportError:
        print(f"Error: Translation file for '{language}' not found.")
        sys.exit(1)

def select_language():
    print("Select language / Seleziona la lingua:")
    print("1. English")
    print("2. Italiano")
    choice = input("Choose an option (1-2): ").strip()
    if choice == '1':
        return "en"
    elif choice == '2':
        return "it"
    else:
        print("Error: Invalid option.")
        sys.exit(1)

def get_password_with_stars(prompt):
    return getpass.getpass(prompt)

def generate_system_key(username, password):
    combined = (username + password).encode('utf-8')
    return hashlib.sha256(combined).hexdigest()

def recover_username(system_key, password):
    try:
        combined = (FIXED_KEY + system_key.encode('utf-8') + password.encode('utf-8'))
        username = hashlib.sha256(combined).hexdigest()
        return username
    except Exception as e:
        print(f"Error in recover_username: {e}")
        return None
