import platform
import sys
import time
import subprocess
from platform_utils import run_command

def bootloader(translations):
    print(translations.STARTING_BOOTLOADER)
    system = platform.system()
    print(translations.DETECTED_OS.format(system))

    if sys.version_info < (3, 6):
        print(translations.PYTHON_VERSION_ERROR)
        sys.exit(1)

    try:
        run_command(f"{sys.executable} -m pip --version")
    except subprocess.CalledProcessError:
        print(translations.PIP_ERROR)
        sys.exit(1)

    libraries = ['cryptography', 'colorama', 'importlib']
    for lib in libraries:
        try:
            __import__(lib)
            print(translations.LIBRARY_INSTALLED.format(lib))
        except ImportError:
            print(translations.LIBRARY_NOT_INSTALLED.format(lib))
            try:
                run_command(f"{sys.executable} -m pip install {lib}")
                print(translations.LIBRARY_INSTALLATION_COMPLETE.format(lib))
            except subprocess.CalledProcessError:
                print(translations.LIBRARY_INSTALLATION_ERROR.format(lib))
                sys.exit(1)

    print(translations.CHECKING, end='', flush=True)
    for _ in range(10):
        print(".", end='', flush=True)
        time.sleep(0.1)
    print(translations.BOOTLOADER_COMPLETE)
